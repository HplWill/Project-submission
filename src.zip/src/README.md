###注意事项

- 清屏功能需将idea快捷键的`清除全部(clear all)`修改为`ctrl+shift+alt+R`可以实现