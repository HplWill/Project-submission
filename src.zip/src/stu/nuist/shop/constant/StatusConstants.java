package stu.nuist.shop.constant;

public class StatusConstants {
    /**
     * 启用
     */
    public static final int ENABLE = 1;
    /**
     * 禁用
     */
    public static final int DISABLE = -1;
}
